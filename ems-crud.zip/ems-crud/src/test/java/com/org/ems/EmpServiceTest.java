package com.org.ems;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.org.ems.EmsModel.Employee;
import com.org.ems.EmsRepo.EmsRepository;

import com.org.ems.EmsServiceImpl.EmsServiceImpl;

@SpringBootTest(classes = { EmpServiceTest.class })

public class EmpServiceTest {

	@Mock
	private EmsRepository empRepository;

	@InjectMocks
	private EmsServiceImpl empServiceImpl;

	@BeforeEach
	public void setUp() {

		Employee employee = new Employee();

		employee.setEmpId(102L);
		employee.setEmpName("yash");
		employee.setEmail("yash@gmail");
		employee.setAddress("Pune");
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(employee);
		when(empServiceImpl.getAllEmp()).thenReturn(employees);

	}

	@Test
	public void addEmployeeTest() {
		Employee employee = new Employee();
		employee.setEmpId(103L);
		employee.setEmpName("yash3");
		employee.setEmail("yash@gmail3");
		employee.setAddress("Pune3");
		// empServiceImpl.addEmployee(employee);
		// verify(empRepository, times(1)).save(employee);
		when(empRepository.save(employee)).thenReturn(employee);

	}

	@Test
	public void getAllEmployeeTest() {

		List<Employee> emp = empServiceImpl.getAllEmp();
		assertEquals(emp.size(), 1);
		// assertEquals(empService.getAllEmp(), emp);
	}

	@Test
	public void deleteEmpByIdTest() {
		long empId = 102L;
		empServiceImpl.deleteEmployee(empId);
		verify(empRepository, times(1)).deleteById(empId);
	}

}
