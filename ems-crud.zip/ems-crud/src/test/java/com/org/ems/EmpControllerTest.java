package com.org.ems;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.Mock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.org.ems.EmsModel.Employee;
import com.org.ems.EmsRepo.EmsRepository;
import com.org.ems.EmsServiceImpl.EmsServiceImpl;
import com.org.ems.web.EmsController;

@WebMvcTest(EmsController.class)

public class EmpControllerTest {

	@Autowired
	MockMvc mockMvc;
	@Mock
	EmsRepository repo;

	@MockBean
	EmsServiceImpl empService;

	@BeforeEach
	public void setUp() {

		Employee employee = new Employee();

		employee.setEmpId(102L);
		employee.setEmpName("yash");
		employee.setEmail("yash@gmail");
		employee.setAddress("Pune");
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(employee);
		when(empService.getAllEmp()).thenReturn(employees);

	}

	@Test
	public void saveEmployeeTest() throws Exception {

		Employee employee = new Employee(104L, "yash4", "gmail4", "pune4");
		ObjectMapper mapper = new ObjectMapper();
		this.mockMvc
				.perform(post("/").contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(employee)))

				.andExpect(status().isOk());

	}

	@Test
	public void getAllEmpTest() throws Exception {
		List<Employee> empList = Arrays.asList(new Employee(102, "e1", "gmail", "pune" ),
				new Employee(103, "e2", "gmail2", "pune2"));

		when(empService.getAllEmp()).thenReturn(empList);

		mockMvc.perform(get("/get"))

				.andExpect(status().isOk())

				.andExpect(content().json("[{}, {}]"));

	}

}
