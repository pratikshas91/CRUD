package com.org.ems.EmsServiceImpl;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.org.ems.EmsModel.Employee;
import com.org.ems.EmsRepo.EmsRepository;


@Component
public class EmsServiceImpl {

	@Autowired EmsRepository emsRepository;

	public Employee addEmployee(Employee employee) {
		return this.emsRepository.save(employee);
		
	}

	
	public List<Employee> getAllEmp() {
		return	new LinkedList<>(this.emsRepository.findAll());
		
	}

	@SuppressWarnings("deprecation")
	
	public Employee updateEmployee(long empId) {
		return	emsRepository.getById(empId);
		
	}


	public void deleteEmployee(long empId) {
		emsRepository.deleteById(empId);
		
	}

}
