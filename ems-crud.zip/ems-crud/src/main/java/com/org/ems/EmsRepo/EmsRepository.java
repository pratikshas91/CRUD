package com.org.ems.EmsRepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.org.ems.EmsModel.Employee;

public interface EmsRepository extends JpaRepository<Employee, Long>{


}
