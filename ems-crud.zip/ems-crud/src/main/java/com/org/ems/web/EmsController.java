package com.org.ems.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.ems.EmsModel.Employee;

import com.org.ems.EmsServiceImpl.EmsServiceImpl;

@RestController
//@RequestMapping("/employee")
public class EmsController {
	@Autowired
	EmsServiceImpl emsServiceImpl;

	@PostMapping("/")
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee) {
		
		this.emsServiceImpl.addEmployee(employee);
		return ResponseEntity.ok(employee);
           

        }
	 @GetMapping(value = "/get")
	    public ResponseEntity<List<Employee>> getAllEmployee() throws RuntimeException {
	        return new ResponseEntity<>(this.emsServiceImpl.getAllEmp(), HttpStatus.OK);
	    }
	 @DeleteMapping("/delete")
	 public void deleteEmployee(long empId)
	 {
		this.emsServiceImpl.deleteEmployee(empId); 
	 }

}
